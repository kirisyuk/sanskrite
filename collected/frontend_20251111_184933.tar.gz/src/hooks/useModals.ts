import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../lib/api';

type ModalType = 'settings' | 'account' | 'admin' | null;
type StaticPageType = 'privacy' | 'terms' | null;

/**
 * Hook для управления модальными окнами и статическими страницами
 */
export function useModals() {
  const { currentUser } = useAuth();
  const [activeModal, setActiveModal] = useState<ModalType>(null);
  const [staticPage, setStaticPage] = useState<StaticPageType>(null);
  const [isAdmin, setIsAdmin] = useState(false);

  // Background-load user preferred language and admin status
  useEffect(() => {
    const loadUserData = async () => {
      try {
        const uid = currentUser?.uid;
        if (!uid) return;
        const user = await api.getUser(uid);
        try {
          const role = (user as any)?.role || '';
          setIsAdmin(
            typeof role === 'string' && role.toLowerCase() === 'admin',
          );
        } catch {}
        const code = (
          user?.preferredLanguage ||
          localStorage.getItem('preferredLanguage') ||
          'EN'
        ).toUpperCase();
        if (code && code.length === 2) {
          localStorage.setItem('preferredLanguage', code);
        }
      } catch {}
    };
    loadUserData();
  }, [currentUser?.uid]);

  const closeAllModals = useCallback(() => {
    setActiveModal(null);
    setStaticPage(null);
  }, []);

  const openSettings = useCallback(() => {
    closeAllModals();
    setActiveModal('settings');
  }, [closeAllModals]);

  const openAccount = useCallback(() => {
    closeAllModals();
    setActiveModal('account');
  }, [closeAllModals]);

  const openAdmin = useCallback(() => {
    closeAllModals();
    setActiveModal('admin');
  }, [closeAllModals]);

  return {
    showSettings: activeModal === 'settings',
    showAccount: activeModal === 'account',
    showAdmin: activeModal === 'admin',
    staticPage,
    setStaticPage,
    isAdmin,
    openSettings,
    openAccount,
    openAdmin,
    closeAllModals,
  };
}

