import React from 'react';
import { useTranslation } from 'react-i18next';
import { api } from '../lib/api';
import { isArtifact, type Artifact } from '../types/artifact';
import type { CoreDoc } from '../types/generated';

interface ArtifactTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  type: 'system' | 'community' | 'custom';
  isFeatured?: boolean;
  defaultStructure?: Array<{
    id: string;
    title: string;
    order: number;
    description: string;
    promptTemplate: string;
    required: boolean;
    editable: boolean;
  }>;
  recommendedFormat?: string;
  recommendedFocus?: string;
}

interface PagesPanelProps {
  projectId: string | null;
  onOpenDocument: (doc: { id: string; filename: string; contentType?: string; sizeBytes?: number; parseStatus?: string }) => void;
  onCreateFromTemplate?: (templateId: string) => void;
}

export const PagesPanel: React.FC<PagesPanelProps> = ({
  projectId,
  onOpenDocument,
  onCreateFromTemplate,
}) => {
  const { t } = useTranslation();
  const [artifacts, setArtifacts] = React.useState<Artifact[]>([]);
  const [templates, setTemplates] = React.useState<ArtifactTemplate[]>([]);
  const [loading, setLoading] = React.useState(false);
  const [templatesLoading, setTemplatesLoading] = React.useState(false);
  const [showTemplates, setShowTemplates] = React.useState(false);
  const [selectedTemplate, setSelectedTemplate] = React.useState<ArtifactTemplate | null>(null);
  const [wizardStep, setWizardStep] = React.useState<'templates' | 'configure'>('templates');
  const [artifactName, setArtifactName] = React.useState('');
  const [creating, setCreating] = React.useState(false);
  const [sectionAutoUpdate, setSectionAutoUpdate] = React.useState<Record<string, boolean>>({});
  const [orchestratorModel, setOrchestratorModel] = React.useState<string>('');
  const [defaultModel, setDefaultModel] = React.useState<string>('');
  const [sectionModels, setSectionModels] = React.useState<Record<string, string>>({});
  const [documentAutoUpdateEnabled, setDocumentAutoUpdateEnabled] = React.useState(false);
  const [autoUpdateTrigger, setAutoUpdateTrigger] = React.useState<'on_new_message' | 'daily' | 'weekly' | 'on_new_document'>('on_new_message');
  const [expandedSections, setExpandedSections] = React.useState<Record<string, boolean>>({});
  const [autoUpdateMinNewMessages, setAutoUpdateMinNewMessages] = React.useState<number | undefined>(undefined);
  const [autoUpdateMinContextChange, setAutoUpdateMinContextChange] = React.useState<number | undefined>(undefined);
  const [autoUpdateKeywords, setAutoUpdateKeywords] = React.useState<string>('');
  const [autoUpdateSearchQueryChanged, setAutoUpdateSearchQueryChanged] = React.useState(false);
  const [autoUpdateCheckQuality, setAutoUpdateCheckQuality] = React.useState(false);
  const [autoUpdateMinQualityThreshold, setAutoUpdateMinQualityThreshold] = React.useState<number>(0.7);
  const [autoUpdateNotifyOnUpdate, setAutoUpdateNotifyOnUpdate] = React.useState(false);

  // Load artifacts
  React.useEffect(() => {
    if (!projectId || projectId === 'local-unfold') {
      setArtifacts([]);
      return;
    }

    const loadArtifacts = async () => {
      setLoading(true);
      try {
        const docs = await api.docsList(projectId);
        const artifactsList = docs.filter((doc: CoreDoc) => isArtifact(doc)) as Artifact[];
        setArtifacts(artifactsList);
      } catch (err) {
        console.error('[PagesPanel] Failed to load artifacts', err);
        setArtifacts([]);
      } finally {
        setLoading(false);
      }
    };

    loadArtifacts();
  }, [projectId]);

  // Load templates
  React.useEffect(() => {
    const loadTemplates = async () => {
      setTemplatesLoading(true);
      try {
        const templatesList = await api.listArtifactTemplates();
        setTemplates(templatesList || []);
      } catch (err) {
        console.error('[PagesPanel] Failed to load templates', err);
        setTemplates([]);
      } finally {
        setTemplatesLoading(false);
      }
    };

    loadTemplates();
  }, []);

  const getArtifactIcon = () => (
    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor">
      <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M14 2v6h6M16 13H8M16 17H8M10 9H8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );

  const getTemplateIcon = () => (
    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor">
      <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M14 2v6h6M12 18v-6M9 15h6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );

  const getFolderIcon = () => (
    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor">
      <path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '';
    try {
      const date = new Date(dateStr);
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    } catch {
      return '';
    }
  };

  // Group templates by category and sort alphabetically within each category
  const groupedTemplates = React.useMemo(() => {
    const grouped = templates.reduce((acc, template) => {
      const category = template.category || 'Other';
      if (!acc[category]) {
        acc[category] = [];
      }
      acc[category].push(template);
      return acc;
    }, {} as Record<string, ArtifactTemplate[]>);

    // Sort categories alphabetically and templates within each category
    return Object.entries(grouped)
      .map(([category, categoryTemplates]) => ({
        category,
        templates: categoryTemplates.sort((a, b) => 
          a.name.localeCompare(b.name, undefined, { sensitivity: 'base' })
        ),
      }))
      .sort((a, b) => 
        a.category.localeCompare(b.category, undefined, { sensitivity: 'base' })
      );
  }, [templates]);

  const handleTemplateSelect = async (templateId: string) => {
    try {
      const fullTemplate = await api.getArtifactTemplate(templateId);
      setSelectedTemplate(fullTemplate);
      setWizardStep('configure');
      setArtifactName(fullTemplate.name || '');
      
      // Initialize models from template recommendations
      const recommendedOrch = fullTemplate.recommendedOrchestratorModel || 'gemini-quality';
      const recommendedSection = fullTemplate.recommendedSectionModel || 'gemini-quality';
      // Normalize to underscore format for consistency
      setOrchestratorModel(recommendedOrch.replace(/-/g, '_'));
      setDefaultModel(recommendedSection.replace(/-/g, '_'));
      
      // Initialize auto-update settings for all sections (default: false)
      const initialAutoUpdate: Record<string, boolean> = {};
      const initialSectionModels: Record<string, string> = {};
      (fullTemplate.defaultStructure || []).forEach((section: { id: string }) => {
        initialAutoUpdate[section.id] = false;
        initialSectionModels[section.id] = recommendedSection.replace(/-/g, '_');
      });
      setSectionAutoUpdate(initialAutoUpdate);
      setSectionModels(initialSectionModels);
      
      // Initialize document auto-update (default: false)
      setDocumentAutoUpdateEnabled(false);
      setAutoUpdateTrigger('on_new_message');
      setAutoUpdateMinNewMessages(undefined);
      setAutoUpdateMinContextChange(undefined);
      setAutoUpdateKeywords('');
      setAutoUpdateSearchQueryChanged(false);
      setAutoUpdateCheckQuality(false);
      setAutoUpdateMinQualityThreshold(0.7);
      setAutoUpdateNotifyOnUpdate(false);
      
      // Initialize expanded sections (default: all collapsed)
      setExpandedSections({});
    } catch (err) {
      console.error('[PagesPanel] Failed to load template', err);
    }
  };

  const handleBack = () => {
    if (wizardStep === 'configure') {
      setWizardStep('templates');
      setSelectedTemplate(null);
      setArtifactName('');
      setSectionAutoUpdate({});
      setOrchestratorModel('');
      setDefaultModel('');
      setSectionModels({});
      setDocumentAutoUpdateEnabled(false);
      setAutoUpdateTrigger('on_new_message');
      setAutoUpdateMinNewMessages(undefined);
      setAutoUpdateMinContextChange(undefined);
      setAutoUpdateKeywords('');
      setAutoUpdateSearchQueryChanged(false);
      setAutoUpdateCheckQuality(false);
      setAutoUpdateMinQualityThreshold(0.7);
      setAutoUpdateNotifyOnUpdate(false);
      setExpandedSections({});
    }
  };

  const handleCreateArtifact = async () => {
    if (!projectId || projectId === 'local-unfold' || !selectedTemplate || !artifactName.trim()) {
      return;
    }

    setCreating(true);
    try {
      // Convert template structure to artifact structure
      const artifactSections = (selectedTemplate.defaultStructure || []).map((section) => {
        const sectionModel = sectionModels[section.id] || defaultModel;
        return {
          id: section.id,
          title: section.title,
          order: section.order,
          prompt: section.promptTemplate,
          model: sectionModel !== defaultModel ? sectionModel.replace(/_/g, '-') : undefined,
          description: section.description,
          required: section.required,
          editable: section.editable,
          autoUpdateEnabled: sectionAutoUpdate[section.id] || false,
        };
      });

      // Generate version ID
      const versionId = `v_${Date.now()}`;

      // Build auto-update config if enabled
      const conditions: any = {};
      if (autoUpdateMinNewMessages !== undefined && autoUpdateMinNewMessages > 0) {
        conditions.minNewMessages = autoUpdateMinNewMessages;
      }
      if (autoUpdateMinContextChange !== undefined && autoUpdateMinContextChange > 0) {
        conditions.minContextChange = autoUpdateMinContextChange;
      }
      if (autoUpdateKeywords.trim()) {
        conditions.keywords = autoUpdateKeywords.split(',').map(k => k.trim()).filter(Boolean);
      }
      if (autoUpdateSearchQueryChanged) {
        conditions.searchQueryChanged = true;
      }

      const smartUpdate = autoUpdateCheckQuality ? {
        checkQuality: true,
        minQualityThreshold: autoUpdateMinQualityThreshold,
        notifyOnUpdate: autoUpdateNotifyOnUpdate,
      } : undefined;

      const autoUpdateConfig = documentAutoUpdateEnabled ? {
        trigger: autoUpdateTrigger,
        conditions: Object.keys(conditions).length > 0 ? conditions : undefined,
        smartUpdate: smartUpdate,
      } : undefined;

      const artifactDoc: Partial<CoreDoc> = {
        filename: artifactName.trim(),
        contentType: 'text/markdown',
        docType: 'dynamic_artifact',
        artifactConfig: {
          format: (selectedTemplate.recommendedFormat || 'text') as 'text' | 'table' | 'report' | 'presentation',
          focus: (selectedTemplate.recommendedFocus || 'analysis') as 'brief' | 'analysis' | 'narrative' | 'proposal' | 'technical' | 'executive',
          orchestratorModel: orchestratorModel.replace(/_/g, '-'),
          defaultModel: defaultModel.replace(/_/g, '-'),
          reviewPrompt: 'Review and refine for clarity, consistency, and completeness.',
          structure: artifactSections,
          contextSources: {},
          autoUpdateEnabled: documentAutoUpdateEnabled,
          autoUpdateConfig: autoUpdateConfig,
          currentVersionID: versionId,
          versionsRetained: 10,
          versions: [],
          generationSettings: {
            preferredLanguage: 'en',
            systemPrompt: 'You are a helpful assistant.',
          },
        },
      };

      const createdDoc = await api.docsCreate(projectId, artifactDoc as any);
      
      // Reload artifacts list
      const docs = await api.docsList(projectId);
      const artifactsList = docs.filter((doc: CoreDoc) => isArtifact(doc)) as Artifact[];
      setArtifacts(artifactsList);

      // Reset wizard and open the created document
      setWizardStep('templates');
      setSelectedTemplate(null);
      setArtifactName('');
      setSectionAutoUpdate({});
      setOrchestratorModel('');
      setDefaultModel('');
      setSectionModels({});
      setDocumentAutoUpdateEnabled(false);
      setAutoUpdateTrigger('on_new_message');
      onOpenDocument(createdDoc);
    } catch (err) {
      console.error('[PagesPanel] Failed to create artifact', err);
    } finally {
      setCreating(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="animate-pulse text-xs" style={{ color: 'var(--text-secondary-strong)' }}>
          Loading pages...
        </div>
      </div>
    );
  }

  // Welcome component
  const WelcomeMessage = ({ template }: { template: NonNullable<typeof selectedTemplate> }) => (
    <div
      className="px-3 py-2.5 rounded-lg"
      style={{
        backgroundColor: 'var(--toolbar-bg)',
        border: '1px solid var(--overlay-line-90)',
      }}
    >
      <p
        className="text-xs mb-2"
        style={{ color: 'var(--text-heading)' }}
      >
        Welcome to <strong>{template.name}</strong> builder.
      </p>
      {template.description && (
        <p
          className="text-[10px] leading-relaxed"
          style={{ color: 'var(--text-secondary-strong)' }}
        >
          {template.description}
        </p>
      )}
    </div>
  );

  // Wizard view - configure artifact from template
  if (wizardStep === 'configure' && selectedTemplate) {
    const sortedSections = [...(selectedTemplate.defaultStructure || [])].sort(
      (a, b) => a.order - b.order
    );

    return (
      <div className="flex flex-col h-full" style={{ minHeight: 0 }}>
        {/* Back button - outside scrollable area */}
        <div className="pb-2">
          <button
            onClick={handleBack}
            className="flex items-center gap-2 text-xs"
            style={{ color: 'var(--text-secondary-strong)' }}
          >
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M15 19l-7-7 7-7"
              />
            </svg>
            Back
          </button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-4 pt-2">
          {/* Welcome message */}
          <WelcomeMessage template={selectedTemplate} />

        {/* Artifact name input */}
        <div>
          <label
            className="block text-13 mb-2"
            style={{ color: 'var(--text-secondary-strong)' }}
          >
            Page name
          </label>
          <input
            type="text"
            value={artifactName}
            onChange={(e) => setArtifactName(e.target.value)}
            placeholder="Enter page name"
            className="w-full text-xs"
            style={{
              backgroundColor: 'transparent',
              border: 'none',
              outline: 'none',
              color: 'var(--text-heading)',
              padding: '8px 0',
              borderBottom: '1px solid var(--overlay-line-90)',
            }}
            onMouseEnter={(e) => {
              const el = e.currentTarget as HTMLInputElement;
              el.style.backgroundColor = 'var(--white-06)';
              el.style.borderRadius = '6px';
              el.style.padding = '8px 8px';
            }}
            onMouseLeave={(e) => {
              const el = e.currentTarget as HTMLInputElement;
              el.style.backgroundColor = 'transparent';
              el.style.borderRadius = '0';
              el.style.padding = '8px 0';
            }}
          />
        </div>

        {/* Document models */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label
              className="block text-13 mb-2"
              style={{ color: 'var(--text-secondary-strong)' }}
            >
              Orchestrator model
            </label>
            <select
              value={orchestratorModel}
              onChange={(e) => setOrchestratorModel(e.target.value)}
              className="w-full text-xs px-2 py-1.5 rounded"
              style={{
                backgroundColor: 'var(--white-06)',
                border: '1px solid var(--overlay-line-90)',
                color: 'var(--text-heading)',
                outline: 'none',
              }}
            >
              <option value="gemini_fast">Gemini Fast</option>
              <option value="gemini_balanced">Gemini Balanced</option>
              <option value="gemini_quality">Gemini Quality</option>
              <option value="gpt_fast">GPT Fast</option>
              <option value="gpt_balanced">GPT Balanced</option>
              <option value="gpt_quality">GPT Quality</option>
              <option value="grok_fast">Grok Fast</option>
              <option value="grok_balanced">Grok Balanced</option>
              <option value="grok_quality">Grok Quality</option>
              <option value="claude_fast">Claude Fast</option>
              <option value="claude_balanced">Claude Balanced</option>
              <option value="deepseek_fast">DeepSeek Fast</option>
              <option value="deepseek_quality">DeepSeek Quality</option>
            </select>
          </div>
          <div>
            <label
              className="block text-13 mb-2"
              style={{ color: 'var(--text-secondary-strong)' }}
            >
              Default section model
            </label>
            <select
              value={defaultModel}
              onChange={(e) => {
                const newDefault = e.target.value;
                setDefaultModel(newDefault);
                // Update sections that currently use the old default model
                setSectionModels((prev) => {
                  const updated = { ...prev };
                  const oldDefault = defaultModel;
                  Object.keys(updated).forEach((sectionId) => {
                    // If section model matches old default or is not set, update to new default
                    if (!prev[sectionId] || prev[sectionId] === oldDefault) {
                      updated[sectionId] = newDefault;
                    }
                  });
                  return updated;
                });
              }}
              className="w-full text-xs px-2 py-1.5 rounded"
              style={{
                backgroundColor: 'var(--white-06)',
                border: '1px solid var(--overlay-line-90)',
                color: 'var(--text-heading)',
                outline: 'none',
              }}
            >
              <option value="gemini_fast">Gemini Fast</option>
              <option value="gemini_balanced">Gemini Balanced</option>
              <option value="gemini_quality">Gemini Quality</option>
              <option value="gpt_fast">GPT Fast</option>
              <option value="gpt_balanced">GPT Balanced</option>
              <option value="gpt_quality">GPT Quality</option>
              <option value="grok_fast">Grok Fast</option>
              <option value="grok_balanced">Grok Balanced</option>
              <option value="grok_quality">Grok Quality</option>
              <option value="claude_fast">Claude Fast</option>
              <option value="claude_balanced">Claude Balanced</option>
              <option value="deepseek_fast">DeepSeek Fast</option>
              <option value="deepseek_quality">DeepSeek Quality</option>
            </select>
          </div>
        </div>

        {/* Document auto-update settings */}
        <div>
          <label className="flex items-center gap-2 cursor-pointer mb-2">
            <input
              type="checkbox"
              checked={documentAutoUpdateEnabled}
              onChange={(e) => setDocumentAutoUpdateEnabled(e.target.checked)}
              className="w-3 h-3"
              style={{
                accentColor: 'var(--accent-primary)',
              }}
            />
            <span
              className="text-13"
              style={{ color: 'var(--text-secondary-strong)' }}
            >
              Enable document auto-update
            </span>
          </label>
          {documentAutoUpdateEnabled && (
            <div className="ml-5 mt-3 space-y-3">
              <div>
                <label
                  className="block text-[11px] mb-1.5"
                  style={{ color: 'var(--text-secondary-strong)' }}
                >
                  Trigger
                </label>
                <select
                  value={autoUpdateTrigger}
                  onChange={(e) => setAutoUpdateTrigger(e.target.value as any)}
                  className="w-full text-xs px-2 py-1.5 rounded"
                  style={{
                    backgroundColor: 'var(--white-06)',
                    border: '1px solid var(--overlay-line-90)',
                    color: 'var(--text-heading)',
                    outline: 'none',
                  }}
                >
                  <option value="on_new_message">On new message</option>
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="on_new_document">On new document</option>
                </select>
              </div>

              <div>
                <label
                  className="block text-[11px] mb-1.5"
                  style={{ color: 'var(--text-secondary-strong)' }}
                >
                  Conditions
                </label>
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label
                        className="block text-[10px] mb-1"
                        style={{ color: 'var(--text-secondary-strong)' }}
                      >
                        Min new messages
                      </label>
                      <input
                        type="number"
                        min="0"
                        value={autoUpdateMinNewMessages || ''}
                        onChange={(e) => setAutoUpdateMinNewMessages(e.target.value ? parseInt(e.target.value) : undefined)}
                        placeholder="Optional"
                        className="w-full text-xs px-2 py-1 rounded"
                        style={{
                          backgroundColor: 'var(--white-06)',
                          border: '1px solid var(--overlay-line-90)',
                          color: 'var(--text-heading)',
                          outline: 'none',
                        }}
                      />
                    </div>
                    <div>
                      <label
                        className="block text-[10px] mb-1"
                        style={{ color: 'var(--text-secondary-strong)' }}
                      >
                        Min context change (0-1)
                      </label>
                      <input
                        type="number"
                        min="0"
                        max="1"
                        step="0.1"
                        value={autoUpdateMinContextChange || ''}
                        onChange={(e) => setAutoUpdateMinContextChange(e.target.value ? parseFloat(e.target.value) : undefined)}
                        placeholder="Optional"
                        className="w-full text-xs px-2 py-1 rounded"
                        style={{
                          backgroundColor: 'var(--white-06)',
                          border: '1px solid var(--overlay-line-90)',
                          color: 'var(--text-heading)',
                          outline: 'none',
                        }}
                      />
                    </div>
                  </div>
                  <div>
                    <label
                      className="block text-[10px] mb-1"
                      style={{ color: 'var(--text-secondary-strong)' }}
                    >
                      Keywords (comma-separated)
                    </label>
                    <input
                      type="text"
                      value={autoUpdateKeywords}
                      onChange={(e) => setAutoUpdateKeywords(e.target.value)}
                      placeholder="Optional"
                      className="w-full text-xs px-2 py-1 rounded"
                      style={{
                        backgroundColor: 'var(--white-06)',
                        border: '1px solid var(--overlay-line-90)',
                        color: 'var(--text-heading)',
                        outline: 'none',
                      }}
                    />
                  </div>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={autoUpdateSearchQueryChanged}
                      onChange={(e) => setAutoUpdateSearchQueryChanged(e.target.checked)}
                      className="w-3 h-3"
                      style={{
                        accentColor: 'var(--accent-primary)',
                      }}
                    />
                    <span
                      className="text-[10px]"
                      style={{ color: 'var(--text-secondary-strong)' }}
                    >
                      Trigger if search query changed
                    </span>
                  </label>
                </div>
              </div>

              <div>
                <label className="flex items-center gap-2 cursor-pointer mb-2">
                  <input
                    type="checkbox"
                    checked={autoUpdateCheckQuality}
                    onChange={(e) => setAutoUpdateCheckQuality(e.target.checked)}
                    className="w-3 h-3"
                    style={{
                      accentColor: 'var(--accent-primary)',
                    }}
                  />
                  <span
                    className="text-[11px]"
                    style={{ color: 'var(--text-secondary-strong)' }}
                  >
                    Smart update (check quality)
                  </span>
                </label>
                {autoUpdateCheckQuality && (
                  <div className="ml-5 mt-2 space-y-2">
                    <div>
                      <label
                        className="block text-[10px] mb-1"
                        style={{ color: 'var(--text-secondary-strong)' }}
                      >
                        Min quality threshold (0-1)
                      </label>
                      <input
                        type="number"
                        min="0"
                        max="1"
                        step="0.1"
                        value={autoUpdateMinQualityThreshold}
                        onChange={(e) => setAutoUpdateMinQualityThreshold(parseFloat(e.target.value))}
                        className="w-full text-xs px-2 py-1 rounded"
                        style={{
                          backgroundColor: 'var(--white-06)',
                          border: '1px solid var(--overlay-line-90)',
                          color: 'var(--text-heading)',
                          outline: 'none',
                        }}
                      />
                    </div>
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={autoUpdateNotifyOnUpdate}
                        onChange={(e) => setAutoUpdateNotifyOnUpdate(e.target.checked)}
                        className="w-3 h-3"
                        style={{
                          accentColor: 'var(--accent-primary)',
                        }}
                      />
                      <span
                        className="text-[10px]"
                        style={{ color: 'var(--text-secondary-strong)' }}
                      >
                        Notify on update
                      </span>
                    </label>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Sections list */}
        {sortedSections.length > 0 && (
          <div>
            <label
              className="block text-13 mb-2"
              style={{ color: 'var(--text-secondary-strong)' }}
            >
              Sections
            </label>
            <div className="space-y-2">
              {sortedSections.map((section) => {
                const isExpanded = expandedSections[section.id] || false;
                return (
                <div
                  key={section.id}
                  className="px-3 py-2 rounded"
                  style={{
                    backgroundColor: 'var(--white-06)',
                    border: '1px solid var(--overlay-line-90)',
                  }}
                >
                  <button
                    type="button"
                    onClick={() => {
                      setExpandedSections((prev) => ({
                        ...prev,
                        [section.id]: !prev[section.id],
                      }));
                    }}
                    className="w-full flex items-center justify-between text-left"
                  >
                    <div
                      className="text-xs font-medium"
                      style={{ color: 'var(--text-heading)' }}
                    >
                      {section.title}
                      {section.required && (
                        <span
                          className="ml-1 text-[10px]"
                          style={{ color: 'var(--text-tertiary-weak)' }}
                        >
                          (required)
                        </span>
                      )}
                    </div>
                    <svg
                      className="w-3 h-3 transition-transform"
                      style={{
                        transform: isExpanded ? 'rotate(180deg)' : 'rotate(0deg)',
                        color: 'var(--text-secondary)',
                      }}
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                    >
                      <path
                        d="M6 9l6 6 6-6"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </button>
                  {isExpanded && (
                    <>
                      {section.description && (
                        <div
                          className="text-[10px] mb-1 mt-2"
                          style={{ color: 'var(--text-secondary-strong)' }}
                        >
                          {section.description}
                        </div>
                      )}
                      {section.promptTemplate && (
                        <div
                          className="text-[10px] mt-1 pt-1"
                          style={{
                            color: 'var(--text-tertiary-weak)',
                            borderTop: '1px solid var(--overlay-line-90)',
                            fontStyle: 'italic',
                          }}
                        >
                          {section.promptTemplate}
                        </div>
                      )}
                      <div
                        className="mt-2 pt-2 space-y-2"
                        style={{
                          borderTop: '1px solid var(--overlay-line-90)',
                        }}
                      >
                        <div>
                          <label
                            className="block text-[10px] mb-1"
                            style={{ color: 'var(--text-secondary-strong)' }}
                          >
                            Model
                          </label>
                          <select
                            value={sectionModels[section.id] || defaultModel}
                            onChange={(e) => {
                              setSectionModels((prev) => ({
                                ...prev,
                                [section.id]: e.target.value,
                              }));
                            }}
                            className="w-full text-[10px] px-2 py-1 rounded"
                            style={{
                              backgroundColor: 'var(--white-06)',
                              border: '1px solid var(--overlay-line-90)',
                              color: 'var(--text-heading)',
                              outline: 'none',
                            }}
                          >
                            <option value="gemini_fast">Gemini Fast</option>
                            <option value="gemini_balanced">Gemini Balanced</option>
                            <option value="gemini_quality">Gemini Quality</option>
                            <option value="gpt_fast">GPT Fast</option>
                            <option value="gpt_balanced">GPT Balanced</option>
                            <option value="gpt_quality">GPT Quality</option>
                            <option value="grok_fast">Grok Fast</option>
                            <option value="grok_balanced">Grok Balanced</option>
                            <option value="grok_quality">Grok Quality</option>
                            <option value="claude_fast">Claude Fast</option>
                            <option value="claude_balanced">Claude Balanced</option>
                            <option value="deepseek_fast">DeepSeek Fast</option>
                            <option value="deepseek_quality">DeepSeek Quality</option>
                          </select>
                        </div>
                        <label className="flex items-center gap-1.5 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={sectionAutoUpdate[section.id] || false}
                            onChange={(e) => {
                              setSectionAutoUpdate((prev) => ({
                                ...prev,
                                [section.id]: e.target.checked,
                              }));
                            }}
                            className="w-3 h-3"
                            style={{
                              accentColor: 'var(--accent-primary)',
                            }}
                          />
                          <span
                            className="text-[10px]"
                            style={{ color: 'var(--text-secondary-strong)' }}
                          >
                            Auto-update
                          </span>
                        </label>
                      </div>
                    </>
                  )}
                </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Create button */}
        <div className="pt-2">
          <button
            onClick={handleCreateArtifact}
            disabled={!artifactName.trim() || creating}
            className="w-full text-xs px-3 py-2 rounded-lg transition-colors"
            style={{
              backgroundColor: artifactName.trim() && !creating
                ? 'var(--accent-primary)'
                : 'var(--white-10)',
              color: artifactName.trim() && !creating
                ? 'white'
                : 'var(--text-secondary-strong)',
              cursor: artifactName.trim() && !creating ? 'pointer' : 'not-allowed',
            }}
            onMouseEnter={(e) => {
              if (artifactName.trim() && !creating) {
                (e.currentTarget as HTMLButtonElement).style.opacity = '0.9';
              }
            }}
            onMouseLeave={(e) => {
              if (artifactName.trim() && !creating) {
                (e.currentTarget as HTMLButtonElement).style.opacity = '1';
              }
            }}
          >
            {creating ? 'Creating...' : 'Create Page'}
          </button>
        </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full" style={{ minHeight: 0 }}>
      <div className="flex-1 overflow-y-auto space-y-4 pt-2">
      {/* Pages (Artifacts) section */}
      {wizardStep === 'templates' && (
      <div>
        <div className="flex items-center justify-between mb-2">
          <h4
            className="text-[11px] uppercase tracking-wide"
            style={{ color: 'var(--text-tertiary-weak)' }}
          >
            Pages ({artifacts.length})
          </h4>
        </div>
        {artifacts.length === 0 ? (
          <div
            className="text-xs py-4 text-center"
            style={{ color: 'var(--text-secondary-strong)' }}
          >
            No pages yet. Create one from a template below.
          </div>
        ) : (
          <div className="space-y-1">
            {artifacts.map((artifact) => (
              <div
                key={artifact.id}
                className="px-2 py-1.5 rounded text-xs flex items-center gap-2 group cursor-pointer"
                style={{
                  backgroundColor: 'transparent',
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLDivElement).style.backgroundColor =
                    'var(--white-10)';
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLDivElement).style.backgroundColor =
                    'transparent';
                }}
                onClick={() => onOpenDocument(artifact)}
              >
                <div style={{ color: 'var(--text-secondary)' }}>
                  {getArtifactIcon()}
                </div>
                <span
                  className="flex-1 truncate"
                  style={{ color: 'var(--text-heading)' }}
                  title={artifact.filename}
                >
                  {artifact.filename}
                </span>
                {artifact.updatedAt && (
                  <span
                    className="text-[10px]"
                    style={{ color: 'var(--text-tertiary-weak)' }}
                  >
                    {formatDate(artifact.updatedAt)}
                  </span>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
      )}

      {/* Templates section */}
      {wizardStep === 'templates' && (
      <div className="mt-6">
        <div className="mb-2">
          <h4
            className="text-[11px] uppercase tracking-wide"
            style={{ color: 'var(--text-tertiary-weak)' }}
          >
            Templates ({templates.length})
          </h4>
        </div>
        <button
          type="button"
          onClick={() => setShowTemplates(!showTemplates)}
          className="w-full flex items-center justify-between px-2 py-1.5 rounded text-xs"
          style={{
            backgroundColor: 'transparent',
            color: 'var(--text-heading)',
          }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLButtonElement).style.backgroundColor =
              'var(--white-10)';
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLButtonElement).style.backgroundColor =
              'transparent';
          }}
        >
          <div className="flex items-center gap-2">
            <div style={{ color: 'var(--text-secondary)' }}>
              {getFolderIcon()}
            </div>
            <span>{showTemplates ? 'Hide templates' : 'Show templates'}</span>
          </div>
          <svg
            className="w-3 h-3 transition-transform"
            style={{
              transform: showTemplates ? 'rotate(180deg)' : 'rotate(0deg)',
              color: 'var(--text-secondary)',
            }}
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
          >
            <path
              d="M6 9l6 6 6-6"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>

        {showTemplates && (
          <div className="mt-2">
            {templatesLoading ? (
              <div
                className="text-xs py-2 text-center"
                style={{ color: 'var(--text-secondary-strong)' }}
              >
                Loading templates...
              </div>
            ) : templates.length === 0 ? (
              <div
                className="text-xs py-2 text-center"
                style={{ color: 'var(--text-secondary-strong)' }}
              >
                No templates available
              </div>
            ) : (
              <div className="space-y-4">
                {groupedTemplates.map(({ category, templates: categoryTemplates }) => (
                  <div key={category}>
                    <div
                      className="text-[10px] uppercase tracking-wide mb-1.5"
                      style={{ color: 'var(--text-tertiary-weak)' }}
                    >
                      {category}
                    </div>
                    <div 
                      className="grid gap-1"
                      style={{
                        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                      }}
                    >
                      {categoryTemplates.map((template) => (
                        <div
                          key={template.id}
                          className="px-2 py-1.5 rounded text-xs flex items-start gap-2 group cursor-pointer"
                          style={{
                            backgroundColor: 'transparent',
                          }}
                          onMouseEnter={(e) => {
                            (e.currentTarget as HTMLDivElement).style.backgroundColor =
                              'var(--white-10)';
                          }}
                          onMouseLeave={(e) => {
                            (e.currentTarget as HTMLDivElement).style.backgroundColor =
                              'transparent';
                          }}
                          onClick={() => handleTemplateSelect(template.id)}
                        >
                          <div className="flex-shrink-0 mt-0.5" style={{ color: 'var(--text-secondary)' }}>
                            {getTemplateIcon()}
                          </div>
                          <div className="flex-1">
                            <div
                              className="font-medium truncate"
                              style={{ color: 'var(--text-heading)' }}
                              title={template.name}
                            >
                              {template.name}
                              {template.isFeatured && (
                                <span
                                  className="ml-1 text-[10px]"
                                  style={{ color: 'var(--accent-primary)' }}
                                >
                                  ★
                                </span>
                              )}
                            </div>
                            {template.description && (
                              <div
                                className="text-[10px] mt-0.5"
                                style={{ 
                                  color: 'var(--text-secondary-strong)',
                                  wordBreak: 'normal',
                                  overflowWrap: 'normal',
                                }}
                              >
                                {template.description}
                              </div>
                            )}
                            {template.category && (
                              <div className="mt-1.5 inline-block">
                                <span
                                  className="text-[10px] px-2 py-0.5 rounded-full"
                                  style={{ 
                                    color: 'var(--text-secondary-strong)',
                                    backgroundColor: 'var(--white-10)',
                                  }}
                                >
                                  {template.category}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
      )}
      </div>
    </div>
  );
};
