import React from 'react';
import { useGenaiChatStore } from '../stores/genaiChatStore';
import { useAuth } from '../contexts/AuthContext';
import { useProjectsStore } from '../stores/projectsStore';
import { api } from '../lib/api';

// Inline lightweight component to fetch and display title suggestions
export const TitleSuggestions: React.FC<{ visible: boolean; onClose: () => void; onAvailableChange?: (available: boolean) => void }> = ({ visible, onClose, onAvailableChange }) => {
  const [titles, setTitles] = React.useState<string[] | null>(null);
  const [loading, setLoading] = React.useState(false);
  // PERFORMANCE FIX: Subscribe only to messages.length, not entire array
  const messagesLength = useGenaiChatStore((s) => s.messages.length);
  const { currentUser } = useAuth();
  const { currentProject } = useProjectsStore();
  const appliedProjectRef = React.useRef<string | null>(null);
  const finalizedRef = React.useRef(false);
  const fetchedForProjectRef = React.useRef<string | null>(null);
  const lastProjectIdRef = React.useRef<string | null>(null);
  
  // Get messages only when needed via getState()
  const getMessages = React.useCallback(() => useGenaiChatStore.getState().messages, []);
  
  // Reset refs when project changes
  React.useEffect(() => {
    const currentPid = currentProject?.id || null;
    if (lastProjectIdRef.current !== currentPid) {
      // Project changed - reset refs
      appliedProjectRef.current = null;
      finalizedRef.current = false;
      fetchedForProjectRef.current = null;
      lastProjectIdRef.current = currentPid;
    }
  }, [currentProject?.id]);
  
  const hasAssistant = React.useMemo(() => {
    const messages = getMessages();
    return messages.some((m) => m.role === 'assistant' && m.content && m.content.trim().length > 0);
  }, [getMessages, messagesLength]);

  React.useEffect(() => {
    let cancelled = false;
    const run = async () => {
      // Require authenticated user and at least first assistant answer
      if (!currentUser?.uid) return;
      if (!hasAssistant) return;
      // Guard: operate only for the active chat project id
      let pid: string | null = null;
      try {
        pid = useGenaiChatStore.getState().projectId;
        const cpid = useProjectsStore.getState().currentProject?.id;
        if (!pid || pid === 'local-unfold' || !cpid || pid !== cpid) return;
      } catch {}
      
      // Check if title was already finalized for this project (priority check)
      try {
        const projectId = pid || currentProject?.id;
        if (projectId && projectId !== 'local-unfold' && typeof window !== 'undefined') {
          finalizedRef.current = window.localStorage.getItem(`chatTitleFinal:${projectId}`) === '1';
        }
        if (finalizedRef.current) {
          // Title already finalized - reset refs for this project and skip
          if (fetchedForProjectRef.current === pid) fetchedForProjectRef.current = null;
          return;
        }
      } catch {}
      
      // Check if project already has a name (not Draft) - skip fetching if so
      try {
        const name = (useProjectsStore.getState().currentProject?.displayName || '').trim();
        if (name && name.toLowerCase() !== 'draft') {
          // Project already has a name - mark as finalized and skip
          if (pid && typeof window !== 'undefined') {
            try { window.localStorage.setItem(`chatTitleFinal:${pid}`, '1'); } catch {}
          }
          finalizedRef.current = true;
          if (fetchedForProjectRef.current === pid) fetchedForProjectRef.current = null;
          return;
        }
      } catch {}
      
      // If we already fetched titles for this project, don't fetch again
      if (fetchedForProjectRef.current === pid) return;
      setLoading(true);
      try {
        // Build messages from local interactions for better signal (summary if available)
        const st = useGenaiChatStore.getState();
        // Take up to 5 latest USER interactions (oldest->newest)
        const userInteractions = st.interactions.filter((it) => it.kind === 'user');
        const last5 = userInteractions.slice(Math.max(0, userInteractions.length - 5));
        const messages = last5.map((it) => ({
          role: 'user' as const,
          text: (it.summary && it.summary.trim()) ? it.summary : it.content,
        }));
        // If empty, fallback to chat messages
        if (messages.length === 0) {
          const chatMessages = getMessages();
          const fallbackAll = chatMessages.filter((m) => m.role === 'user');
          const fallbackLast5 = fallbackAll.slice(Math.max(0, fallbackAll.length - 5));
          const fallback: Array<{ role: 'user'; text: string }> = fallbackLast5.map((m) => ({ role: 'user', text: m.content }));
          fallback.forEach((mm) => messages.push(mm));
        }
        const res = await api.suggestChatTitles(messages as Array<{ role: 'user'|'assistant'|'system'|'note'; text: string }>);
        if (!cancelled) {
          setTitles(res);
          // Mark this project as having titles fetched
          if (pid) fetchedForProjectRef.current = pid;
        }
      } catch {
        if (!cancelled) setTitles([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    run();
    return () => { cancelled = true; };
  }, [messagesLength, currentUser?.uid, hasAssistant, currentProject?.id, getMessages]);

  React.useEffect(() => {
    try { onAvailableChange && onAvailableChange(!!(titles && titles.length > 0)); } catch {}
  }, [titles?.length]);

  // When title suggestions appear, set the first suggestion as chat title, switch view to discovery and persist
  React.useEffect(() => {
    try {
      if (!titles || titles.length === 0) return;
      const first = (titles[0] || '').trim();
      if (!first) return;
      try {
        const activePid = useGenaiChatStore.getState().projectId;
        const sidePid = useProjectsStore.getState().currentProject?.id;
        console.log('[Titles] apply candidate', { first, activePid, sidePid });
      } catch {}
      // Guard: only auto-apply for the exact active chat project id
      const activePid = ((): string | null => { try { return useGenaiChatStore.getState().projectId || null; } catch { return null; } })();
      if (!activePid || !currentProject?.id || activePid !== currentProject.id) return;
      const proj = currentProject;
      if (!proj?.id) {
        // Hydrate currentProject from genaiChat if it was created via ensureProject()
        (async () => {
          try {
            const pid = activePid;
            if (pid && pid !== 'local-unfold') {
              const p = await api.getProject(pid);
              useProjectsStore.setState((prev) => ({
                projects: [p as any, ...prev.projects.filter((x) => x.id !== (p as any).id)],
                currentProject: p as any,
              }));
            }
          } catch {}
        })();
        return;
      }
      if (appliedProjectRef.current === proj.id) return; // already applied for this project instance
      if ((proj.displayName || '').trim() === first && (proj.view || '') === 'discovery') { appliedProjectRef.current = proj.id; return; }
      (async () => {
        try {
          await api.updateProject(activePid, { displayName: first, view: 'discovery' } as any);
          console.log('[Titles] auto-applied to project', { projectId: activePid, name: first });
          
          // Get updated project data from server to ensure consistency
          let updatedProject: any;
          try {
            updatedProject = await api.getProject(activePid);
          } catch {
            // Fallback to local update if fetch fails
            updatedProject = { ...(currentProject || proj), id: activePid, displayName: first, view: 'discovery' };
          }
          
          useProjectsStore.setState((prev) => {
            const exists = prev.projects.some((p) => p.id === activePid);
            const updated = { ...updatedProject, id: activePid, displayName: first, view: 'discovery' } as any;
            console.log('[Titles] updating projects store', { exists, activePid, updated });
            return {
              projects: exists
                ? prev.projects.map((p) => (p.id === activePid ? updated : p))
                : [updated, ...prev.projects],
              currentProject: updated,
            } as any;
          });
          
          // Also refresh projects list from server to ensure consistency (especially if project was draft)
          try {
            const { fetchProjects } = useProjectsStore.getState();
            await fetchProjects('discovery');
            console.log('[Titles] refreshed projects list from server');
          } catch (e) {
            console.warn('[Titles] failed to refresh projects list', e);
          }
          
          appliedProjectRef.current = activePid;
          // Finalize: suppress future suggestions and hide component permanently
          try { if (typeof window !== 'undefined') window.localStorage.setItem(`chatTitleFinal:${activePid}`, '1'); } catch {}
          finalizedRef.current = true;
          try { onAvailableChange && onAvailableChange(false); } catch {}
          try { onClose && onClose(); } catch {}
          setTitles(null);
        } catch {}
      })();
    } catch {}
  }, [titles && titles[0], currentProject?.id]);
  // Never render UI; only background auto-apply logic is kept
  return null;
};

